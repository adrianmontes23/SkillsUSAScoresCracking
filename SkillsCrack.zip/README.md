Version 3.0
- Whats new
-- no need for chrome driver now, lol
-- however you prob need admin rights now

Description:
This program only allows the distric 8 competition of 2023 but could be changed by me
let me know I'll update where needed.
This Program allows you to find someones score based off of their contestant number or date of birth.
It will create a file with their name, school, competition, contestant number, and their birthday.
The Program makes you set a specific range so you can have mulitple insances or if you know a range,
make it find faster.
The birthday range starts in a format of (01/01/XXXX)
To traverse through the competition simply use the arrow keys.
The speed of this program is soley dependent on the speed of the system and network
The file will be saved in the same folder as the program

DISCLAIMER:
You're doing this at your own risk, I am not responsible for anyone getting in trouble. 
It's not guaranteed To find every contestant as some people don't have birthdays input correctly.
This program consumes large ammounts of bandwidth and network usage.

Signed Adrian Montes(3/10/2023 - 2:32PM)