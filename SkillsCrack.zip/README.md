# Version 3.2
## Whats new
-- only shows the texas state competittion for 2023
-- more better everything since I learned.

## Description:
This program only allows the distric  competition of 2023 but could be changed by me
let me know I'll update where needed.
This Program allows you to find someones score based off of their contestant number or date of birth.
It will create a file with their name, school, competition, contestant number, and their birthday.
The Program makes you set a specific range so you can have mulitple insances or if you know a range,
make it find faster.
The birthday range starts in a format of (01/01/XXXX)
To traverse through the competition simply use the arrow keys.
The speed of this program is soley dependent on the speed of the system and network
The file will be saved in the same folder as the program

## DISCLAIMER:
You're doing this at your own risk, I am not responsible for anyone getting in trouble. 
It's not guaranteed To find every contestant as some people don't have birthdays input correctly.
This program consumes large ammounts of bandwidth and network usage.
You need Admin rights to run the program

Signed Adrian Montes(04/06/2023 - 2:22PM)